#!/bin/bash

set -e

echo "Stopping old container (if any)..."
docker stop group90-mlops || true
docker rm group90-mlops || true

echo "Pulling latest image from Docker Hub..."
docker pull $DOCKER_USERNAME/group90-mlops:latest

echo "Starting new container..."
docker run -d --name group90-mlops -p 8000:8000 $DOCKER_USERNAME/group90-mlops:latest

echo "Deployment complete. App is running at http://localhost:8000"
