from fastapi import FastAPI
import joblib
import pandas as pd
from pydantic import BaseModel
import logging
from datetime import datetime
import os

# Logging setup
os.makedirs("logs", exist_ok=True)
logging.basicConfig(filename="logs/predictions.log", level=logging.INFO,
                    format="%(asctime)s - %(levelname)s - %(message)s")

# FastAPI app
app = FastAPI(title="ML Model API", version="1.0")

# Load model
model = joblib.load("app/models/best_model.pkl")

# Request schema
class Features(BaseModel):
    features: list

@app.get("/")
def root():
    return {"message": "ML Model API is running"}

@app.post("/predict")
def predict(data: Features):
    df = pd.DataFrame([data.features])
    prediction = model.predict(df)[0]

    # Log prediction
    logging.info(f"Input: {data.features} - Prediction: {prediction}")

    return {"prediction": str(prediction)}

@app.get("/metrics")
def metrics():
    # Simple count of predictions from logs
    try:
        with open("logs/predictions.log", "r") as f:
            lines = f.readlines()
        return {"total_predictions": len(lines)}
    except FileNotFoundError:
        return {"total_predictions": 0}
