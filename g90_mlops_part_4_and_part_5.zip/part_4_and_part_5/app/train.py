import os
import pandas as pd
from sklearn.datasets import load_iris
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import RobustScaler
from sklearn.impute import SimpleImputer
from sklearn.feature_selection import VarianceThreshold
from sklearn.linear_model import LogisticRegression
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import accuracy_score
import joblib
import mlflow
from mlflow.models.signature import infer_signature

# ============
# Data loading & preprocessing
# ============
iris = load_iris(as_frame=True)
df = iris.frame

X = df.drop(columns=["target"])
y = df["target"]

X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.3, random_state=42, stratify=y
)

imputer = SimpleImputer(strategy='mean')
X_train = imputer.fit_transform(X_train)
X_test = imputer.transform(X_test)

scaler = RobustScaler()
X_train = scaler.fit_transform(X_train)
X_test = scaler.transform(X_test)

selector = VarianceThreshold(threshold=0.01)
X_train = selector.fit_transform(X_train)
X_test = selector.transform(X_test)

# ============
# Model training & MLflow logging
# ============
mlflow.set_experiment("Iris_Model_Comparison")

def log_model_with_mlflow(model, model_name, params):
    with mlflow.start_run() as run:
        model.fit(X_train, y_train)
        preds = model.predict(X_test)
        acc = accuracy_score(y_test, preds)

        mlflow.log_params(params)
        mlflow.log_metric("accuracy", acc)

        signature = infer_signature(X_test, preds)
        mlflow.sklearn.log_model(model, model_name,
                                 signature=signature,
                                 input_example=X_test[:1])
        return model, acc

log_reg, acc_lr = log_model_with_mlflow(
    LogisticRegression(max_iter=200),
    "LogisticRegression",
    {"max_iter": 200}
)

rf_model, acc_rf = log_model_with_mlflow(
    RandomForestClassifier(n_estimators=100, random_state=42),
    "RandomForest",
    {"n_estimators": 100, "random_state": 42}
)

if acc_lr >= acc_rf:
    best_model = log_reg
    best_name = "LogisticRegression"
    best_acc = acc_lr
else:
    best_model = rf_model
    best_name = "RandomForest"
    best_acc = acc_rf

print(f"Best model: {best_name} (accuracy: {best_acc:.4f})")

# ============
# Save model to correct location
# ============
os.makedirs("app/models", exist_ok=True)
joblib.dump(best_model, "app/models/best_model.pkl")
print("Model saved to app/models/best_model.pkl")
